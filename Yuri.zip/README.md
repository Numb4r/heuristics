# heuristics
A Python module that implements some common heuristics for combinatorial optimization problems.
