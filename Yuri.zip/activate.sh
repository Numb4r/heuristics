#!/bin/sh

source ${pwd}/.venv/bin/activate